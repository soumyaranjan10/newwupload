[ GCS Bucket Made Public](../rules/gcp_audit_rules/gcp_gcs_public.py)

[ GCP Resource in Unused Region](../rules/gcp_audit_rules/gcp_unused_regions.py)

[ GCP SQL Config Changes](../rules/gcp_audit_rules/gcp_sql_config_changes.py)

[ GCP GCS IAM Permission Changes](../rules/gcp_audit_rules/gcp_gcs_iam_changes.py)

[ GCP IAM Role Has Changed](../rules/gcp_audit_rules/gcp_iam_custom_role_changes.py)

[ GCP Corporate Email Not Used](../rules/gcp_audit_rules/gcp_iam_corp_email.py)

