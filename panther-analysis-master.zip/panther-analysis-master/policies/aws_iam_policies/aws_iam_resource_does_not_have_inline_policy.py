def policy(resource):
    return not resource["InlinePolicies"]
