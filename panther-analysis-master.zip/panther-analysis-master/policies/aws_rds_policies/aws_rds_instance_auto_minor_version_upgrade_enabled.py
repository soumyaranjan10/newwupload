def policy(resource):
    return resource["AutoMinorVersionUpgrade"]
