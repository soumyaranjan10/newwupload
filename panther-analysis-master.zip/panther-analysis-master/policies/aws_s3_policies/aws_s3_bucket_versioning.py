def policy(resource):
    return resource["Versioning"] == "Enabled"
